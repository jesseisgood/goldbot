# SilverBot
SilverBot Is A Unbranded Lobby Bot That Is Awesome For Trolling

# Info

For The Default Skin You Can [Join Our Discord Server](discord.gg/hmXa5cQCJH) And Do The Command ?item item name to get the ID of that cosmetic and put in the Settings.json where it goes

In The V3 Update The Still Is No Join Message So Have Fun Trolling Your Friends :)

# Support

For Any More Support [Join Our Discord](discord.gg/hmXa5cQCJH)
